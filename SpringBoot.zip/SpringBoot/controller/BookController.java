package com.SpringBoot.controller;

import java.security.PublicKey;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBoot.model.Book;
import com.SpringBoot.repo.BookRepository;

import jakarta.transaction.Transactional;
@RequestMapping("/book")
@RestController

public class BookController {
	
	@Autowired
	BookRepository bookRepository;
	//create book
     @PostMapping("/books")
	public String insertbook(@RequestBody Book book) {
    	 System.out.println("inside the method of insert book");
    	 bookRepository.save(book);
	      return "Record Successfully"; 	
	}
     @GetMapping("/allbooks")
     public List<Book> getAllBooks()   {  
    	return bookRepository.findAll(); 
       
     } 
   //creating a get mapping that retrieves the detail of a specific book  \
     @GetMapping("/books/{bookId}")
     public Book getBook(@PathVariable("bookId")int bookId) {
		return bookRepository.getById(bookId);
    	 
     }
   //creating a delete mapping that deletes a specified book  
     @DeleteMapping("/book/{bookid}")   
     private void deleteBook(@PathVariable("bookid") int bookid)   
     {  
     bookRepository.deleteById(bookid);  
     }
     
   //creating put mapping that updates the book detail   


    // @Transactional
     //@PutMapping("/update")
    public void update(Book book) {
    	Optional<Book>optional=bookRepository.findById(2);
    	Book book2=optional.get();
    	 book.setBookName("c");
    	 book.setBookAuthor("123");
    	 bookRepository.save(book);
    	 Book book3=bookRepository.save(book);
    	 System.out.println(book3);
    	 System.out.println("Update successfully");
     }
}
